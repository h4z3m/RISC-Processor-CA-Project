# Computer Architecture Project

---

### Team members
| Name   | ID |
| ------ | --- |
| Ahmed Ameen | 1190071  |
| Ali Hassan   | 2200011 |
| Hazem Montasser| 2200003 |
| Yousef Mahmoud Gilany|4200342|

# Assembler 

Python code provides an assembler for our RISC-like ISA. The assembler takes an input file containing assembly code and generates binary code that can be loaded into a memory module in ModelSim. The output can be in either binary or hexadecimal format.


## Semi-RISC Harvard, 6 stages, MIPS pipelined processor

- [DESCRIPTION IN PROGRESS]


### Team members

1. Ahmed Ameen
2. Ali Hassan
3. Hazem Montasser
4. Yousef Gilany
